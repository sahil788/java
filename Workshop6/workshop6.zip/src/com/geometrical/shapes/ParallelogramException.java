package com.geometrical.shapes;

@SuppressWarnings("serial")
public class ParallelogramException extends Exception{
	
	public ParallelogramException() {
		super();
	}
	
	public ParallelogramException(String message) {
		super(message);
	}
	
}
