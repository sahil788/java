package com.geometrical.shapes;

@SuppressWarnings("serial")
public class SquareException extends Exception{

	public SquareException() {
		super();
	}
	
	public SquareException(String message) {
		super(message);
	}
	
}
