package com.geometrical.shapes;

@SuppressWarnings("serial")
public class CircleException extends Exception {

	public CircleException() {
		super();
	}
	
	public CircleException(String message) {
		super(message);
	}
	
}
