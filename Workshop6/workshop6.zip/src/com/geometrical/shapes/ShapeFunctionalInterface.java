package com.geometrical.shapes;

@FunctionalInterface
public interface ShapeFunctionalInterface {
	public double getArea();
}
