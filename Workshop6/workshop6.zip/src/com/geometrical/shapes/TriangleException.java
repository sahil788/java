package com.geometrical.shapes;

@SuppressWarnings("serial")
public class TriangleException extends Exception{

	public TriangleException() {
		super();
	}
	
	public TriangleException(String message) {
		super(message);
	}
	
}
