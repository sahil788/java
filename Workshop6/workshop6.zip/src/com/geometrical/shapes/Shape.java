package com.geometrical.shapes;

public interface Shape {
	
	public double getPerimeter();

}
